import { useState } from 'react'
import { ArrowDown, ArrowRight, ArrowUpRight, AudioLines, Bot, BrainCircuit, ChevronDown, CircleHelp, FileText, Menu, MessageCircle, Orbit, Search, ShieldCheck, Sparkles, X } from 'lucide-react'
import CosmicStarfield from './components/CosmicStarfield.jsx'
import EnergyPlanet from './components/EnergyPlanet.jsx'
const capabilities = [
  { icon: MessageCircle, title: 'Chat with AI', text: 'Think through ideas, solve problems, and explore questions with your AI workspace.', tag: 'CONVERSATIONS' },
  { icon: Bot, title: 'Specialized agents', text: 'Bring focused assistance to coding, reviewing, testing, and research workflows.', tag: 'AI AGENTS' },
  { icon: BrainCircuit, title: 'Knowledge retrieval', text: 'Find useful context across your project knowledge and documents.', tag: 'YOUR KNOWLEDGE' },
  { icon: FileText, title: 'File analysis', text: 'Explore documents and extract the details that matter to your work.', tag: 'DOCUMENTS' },
]

export default function App() {
  const [menuOpen, setMenuOpen] = useState(false)
  const [showNotice, setShowNotice] = useState(false)

  const enterProject = () => {
    setShowNotice(true)
    document.getElementById('capabilities')?.scrollIntoView({ behavior: 'smooth' })
  }

  return (
    <main className="site-shell">
      <CosmicStarfield />
      <header className="topbar">
        <a className="brand" href="#home" aria-label="ProjectMind AI home">
          <span className="brand-mark"><Orbit size={19} strokeWidth={1.8} /></span>
          <span>ProjectMind<span className="brand-ai"> AI</span></span>
        </a>
        <button className="mobile-menu" onClick={() => setMenuOpen(!menuOpen)} aria-label="Toggle navigation">
          {menuOpen ? <X size={20} /> : <Menu size={20} />}
        </button>
        <nav className={menuOpen ? 'nav-links nav-open' : 'nav-links'} aria-label="Main navigation">
          <a href="#home" onClick={() => setMenuOpen(false)}>Home</a>
          <a href="#capabilities" onClick={() => setMenuOpen(false)}>Capabilities</a>
          <a href="#about" onClick={() => setMenuOpen(false)}>About</a>
        </nav>
        <button className="sign-in" onClick={() => setShowNotice(true)}>Sign in <ArrowUpRight size={15} /></button>
      </header>

      <section className="hero" id="home">
        <div className="hero-copy">
          <div className="eyebrow"><span className="status-dot" /> YOUR INTELLIGENT WORKSPACE</div>
          <h1>Think beyond<br /><span>boundaries.</span></h1>
          <p className="hero-subtitle">A new orbit for your ideas. Bring coding, research, and discovery into one intelligent workspace.</p>
          <div className="hero-actions">
            <button className="primary-button" onClick={enterProject}>Enter ProjectMind <ArrowRight size={17} /></button>
            <a className="secondary-button" href="#capabilities">Explore capabilities <ArrowDown size={15} /></a>
          </div>
          <div className="trust-line"><ShieldCheck size={15} /> Built for focused thinking and meaningful work</div>
        </div>
        <div className="planet-stage" aria-label="Interactive animated energy orb">
          <div className="planet-halo" />
          <EnergyPlanet />
          <div className="planet-caption"><span className="caption-pulse" /> PROJECTMIND GALAXY <span className="caption-line" /></div>
          <div className="floating-label label-one"><Sparkles size={14} /> A universe of ideas</div>
          <div className="floating-label label-two"><AudioLines size={14} /> Move to explore</div>
        </div>
        <div className="hero-bottom-note"><span>01</span> AN INTELLIGENT SPACE FOR WHAT'S NEXT</div>
        <a className="scroll-cue" href="#capabilities" aria-label="Scroll to capabilities"><span /> Scroll to explore</a>
      </section>

      <section className="capabilities section-wrap" id="capabilities">
        <div className="section-heading">
          <div>
            <div className="eyebrow">ONE WORKSPACE. MANY POSSIBILITIES.</div>
            <h2>Everything you need to<br /><span>move ideas forward.</span></h2>
          </div>
          <p>Thoughtfully connected tools for turning questions into clarity and concepts into progress.</p>
        </div>
        <div className="capability-grid">
          {capabilities.map(({ icon: Icon, title, text, tag }, i) => (
            <article className="capability-card" key={title} style={{ '--card-index': i }}>
              <div className="card-top"><span className="cap-icon"><Icon size={19} /></span><span className="card-index">0{i + 1}</span></div>
              <div className="card-tag">{tag}</div>
              <h3>{title}</h3>
              <p>{text}</p>
              <button className="card-link" onClick={() => setShowNotice(true)} aria-label={`Explore ${title}`}>Explore <ArrowUpRight size={15} /></button>
            </article>
          ))}
        </div>
      </section>

      <section className="about-strip section-wrap" id="about">
        <div className="about-orbit"><Orbit size={26} /></div>
        <div><div className="eyebrow">MADE FOR CURIOSITY</div><h2>Your next idea starts <span>somewhere.</span></h2></div>
        <a href="#home" className="back-top">Back to top <ArrowUpRight size={16} /></a>
      </section>

      <footer className="footer">
        <a className="brand footer-brand" href="#home"><span className="brand-mark"><Orbit size={17} /></span><span>ProjectMind<span className="brand-ai"> AI</span></span></a>
        <span>© 2026 ProjectMind AI · A workspace for curious minds.</span>
        <a href="#about" className="footer-help"><CircleHelp size={14} /> About this project</a>
      </footer>

      {showNotice && (
        <div className="notice-backdrop" role="presentation" onClick={() => setShowNotice(false)}>
          <div className="notice-panel" role="dialog" aria-modal="true" aria-labelledby="notice-title" onClick={e => e.stopPropagation()}>
            <button className="notice-close" onClick={() => setShowNotice(false)} aria-label="Close"><X size={18} /></button>
            <span className="notice-icon"><Sparkles size={22} /></span>
            <div className="eyebrow">COMING IN THE NEXT PHASE</div>
            <h2 id="notice-title">The next orbit is taking shape.</h2>
            <p>This homepage is the visual foundation. We'll build the login experience next, then connect the app to your existing Python backend.</p>
            <button className="primary-button notice-action" onClick={() => setShowNotice(false)}>Sounds good <ArrowRight size={16} /></button>
          </div>
        </div>
      )}
    </main>
  )
}